 Summary of important user-visible changes for statistics 1.6.0:
-------------------------------------------------------------------

 Important Notice: 1) dependency changed to Octave>=7.2.0
                   2) various distribution functions have been
                       renamed, deprecated, or modified extensively
                       so that backwards compatibility is broken
                   3) `mad`, `mean`, `median`, `std`, `var` functions
                       shadow core Octave's respective functions
                   4) incompatibility with the `nan` package
 New functions:
 ==============

 ** betafit (fully Matlab compatible)

 ** betalike (fully Matlab compatible)

 ** binofit (fully Matlab compatible)

 ** binolike (similar functionality to MATLAB's negloglik)

 ** bisafit (similar functionality to MATLAB's mle)

 ** bisalike (similar functionality to MATLAB's negloglik and mlecov)

 ** burrfit (similar functionality to MATLAB's mle)

 ** burrlike (similar functionality to MATLAB's negloglik and mlecov)

 ** einstein (plotting function for the einstein tile)

 ** geofit (similar functionality to MATLAB's mle)

 ** gumbelcdf

 ** gumbelfit (similar functionality to MATLAB's mle)

 ** gumbelinv

 ** gumbellike (similar functionality to MATLAB's negloglik and mlecov)

 ** gumbelpdf

 ** gumbelrnd

 ** hncdf

 ** hnfit (similar functionality to MATLAB's mle)

 ** hninv

 ** hnlike (similar functionality to MATLAB's negloglik and mlecov)

 ** hnpdf

 ** hnrnd

 ** invgcdf

 ** invgfit (similar functionality to MATLAB's mle)

 ** invginv

 ** invglike (similar functionality to MATLAB's negloglik and mlecov)

 ** invgpdf

 ** invgrnd

 ** isoutlier (fully Matlab compatible)

 ** logifit (similar functionality to MATLAB's mle)

 ** logilike (similar functionality to MATLAB's negloglik and mlecov)

 ** loglcdf

 ** loglfit (similar functionality to MATLAB's mle)

 ** loglinv

 ** logllike (similar functionality to MATLAB's negloglik and mlecov)

 ** loglpdf

 ** loglrnd

 ** lognfit (fully Matlab compatible)

 ** lognlike (fully Matlab compatible)

 ** nakafit (similar functionality to MATLAB's mle)

 ** nakalike (similar functionality to MATLAB's negloglik and mlecov)

 ** nbinfit (similar functionality to MATLAB's mle)

 ** nbinlike (similar functionality to MATLAB's negloglik and mlecov)

 ** mad (fully Matlab compatible)

 ** normfit (fully Matlab compatible)

 ** poissfit (fully Matlab compatible, extra functionality)

 ** poisslike (similar functionality to MATLAB's negloglik)

 ** raylfit (fully Matlab compatible, extra functionality)

 ** rayllike (similar functionality to MATLAB's negloglik)

 ** ridge (fully Matlab compatible)

 ** unidfit (similar functionality to MATLAB's mle)

 ** unifit (similar functionality to MATLAB's mle)

 ** vminv (quantile function for the von Mises distribution)

 ** wblfit (fully Matlab compatible)

 ** wbllike (fully Matlab compatible)

 Improvements:
 =============

 ** bisacdf: supports "upper" option

 ** burrcdf: supports "upper" option

 ** cauchycdf: supports "upper" option

 ** cdf: update support for all univariate cumulative distribution functions

 ** gamfit: fixed MATLAB compatibility

 ** gamlike: fixed MATLAB compatibility

 ** icdf: update support for all univariate quantile functions

 ** laplacecdf: supports "upper" option

 ** logicdf: supports "upper" option

 ** mcnemar_test: updated functionality

 ** nakacdf: supports "upper" option

 ** pcacov: fixed MATLAB compatibility

 ** pdf: update support for all univariate probability density functions

 ** plsregress: fixed MATLAB compatibility

 ** random: update support for all univariate functions

 ** runstest: fixed MATLAB compatibility

 ** tabulate: fixed MATLAB compatibility

 ** tricdf: supports "upper" option

 ** trimmean: fixed MATLAB compatibility

 Removed Functions:
 ==================

 ** run_test (replaced by runstest)

 ** stdnormal_cdf (replaced by normcdf)

 ** stdnormal_inv (replaced by norminv)

 ** stdnormal_pdf (replaced by normpdf)

 ** stdnormal_rnd (replaced by normrnd)

 Renamed Functions:
 ==================

 ** bisacdf (replacing bbscdf)

 ** bisainv (replacing bbsinv)

 ** bisapdf (replacing bbspdf)

 ** bisarnd (replacing bbsrnd)

 ** cauchycdf (replacing cauchy_cdf)

 ** cauchyinv (replacing cauchy_inv)

 ** cauchypdf (replacing cauchy_pdf)

 ** cauchyrnd (replacing cauchy_rnd)

 ** laplacecdf (replacing laplace_cdf)

 ** laplaceinv (replacing laplace_inv)

 ** laplacepdf (replacing laplace_pdf)

 ** laplacernd (replacing laplace_rnd)

 ** logicdf (replacing logistic_cdf)

 ** logiinv (replacing logistic_inv)

 ** logipdf (replacing logistic_pdf)

 ** logirnd (replacing logistic_rnd)


 Summary of important user-visible changes for statistics 1.6.1:
-------------------------------------------------------------------

 Important Notice: 1) `mad`, `mean`, `median`, `std`, `var` functions
                      shadow core Octave's respective functions prior
                      to Octave v9.1
                   2) incompatibility with the `nan` package
 New functions:
 ==============

 ** ClassificationKNN (new classdef)

 ** predict (for ClassificationKNN classdef)

 ** fitcknn

 ** fitrgam

 ** knnsearch (fully Matlab compatible)

 ** mnrfit

 ** rangesearch (fully Matlab compatible)

 ** RegressionGAM (new classdef)

 ** predict (for RegressionGAM classdef)

 Improvements:
 =============

 ** anovan: new features

 ** friedman: bug fixes

 ** pdist: updated functionality, fully MATLAB compatible

 ** pdist2: updated functionality, fully MATLAB compatible

 ** regress_gp: updated functionality with RBF kernel

 ** ridge: bug fixes


 Summary of important user-visible changes for statistics 1.6.2:
-------------------------------------------------------------------

 Important Notice: 1) `mad`, `mean`, `median`, `std`, `var` functions
                      shadow core Octave's respective functions prior
                      to Octave v9.1
                   2) incompatibility with the `nan` package
 New functions:
 ==============

 ** ricecdf

 ** riceinv

 ** ricepdf

 ** ricernd

 Improvements:
 =============

 ** changed ClassificationKNN legacy class to classdef

 ** changed RegressionGAM legacy class to classdef

 ** update figure handling in BISTs, bug fix when calling 'pkg test statistics'


 Summary of important user-visible changes for statistics 1.6.3:
-------------------------------------------------------------------

 Important Notice: 1) `mad`, `mean`, `median`, `std`, `var` functions
                      shadow core Octave's respective functions prior
                      to Octave v9.1
                   2) incompatibility with the `nan` package
 New functions:
 ==============

 ** ricefit

 ** ricelike

 ** ricestat

 ** tlscdf

 ** tlsinv

 ** tlspdf

 ** tlsrnd

 ** tlsstat

 Improvements:
 =============

 ** cdf: add support for Rician and location-scale T distributions

 ** gevlike: deprecate gradient as a second output argument (undocumented)

 ** icdf: add support for Rician and location-scale T distributions

 ** pdf: add support for Rician and location-scale T distributions

 ** random: add support for Rician and location-scale T distributions

 ** ricernd: fixed bug that produced erroneous results

 ** updated input validation and documentation to distribution *stat functions


 Summary of important user-visible changes for statistics 1.6.4:
-------------------------------------------------------------------

 Important Notice: 1) `mad`, `mean`, `median`, `std`, `var` functions
                      shadow core Octave's respective functions prior
                      to Octave v9.1
                   2) incompatibility with the `nan` package
 New functions:
 ==============

 ** bisastat

 ** burrstat

 ** fitdist

 ** glmfit (needs a lot of work yet)

 ** hnstat

 ** invgstat

 ** logistat

 ** loglstat

 ** makedist

 ** mle

 ** nakastat

 ** plcdf

 ** plinv

 ** plpdf

 ** plrnd

 ** plstat

 ** tlsfit

 ** tlslike

 ** tristat

 New classdefs:
 ==============

 ** BetaDistribution

 ** BinomialDistribution (methods on truncated distributions do not work yet)

 ** BirnbaumSaundersDistribution

 ** BurrDistribution

 ** ExponentialDistribution

 ** ExtremeValueDistribution

 ** GammaDistribution

 ** GeneralizedExtremeValueDistribution

 ** GeneralizedParetoDistribution

 ** HalfNormalDistribution

 ** InverseGaussianDistribution

 ** LogisticDistribution

 ** LoglogisticDistribution

 ** LognormalDistribution

 ** LoguniformDistribution

 ** MultinomialDistribution

 ** NakagamiDistribution

 ** NegativeBinomialDistribution
    (methods on truncated distributions do not work yet)

 ** NormalDistribution

 ** PiecewiseLinearDistribution
    ('mean', 'std', and 'var' methods fail for truncated distributions)

 ** PoissonDistribution (methods on truncated distributions do not work yet)

 ** RayleighDistribution

 ** RicianDistribution

 ** tLocationScaleDistribution

 ** TriangularDistribution

 ** UniformDistribution

 ** WeibullDistribution

 Improvements:
 =============

 ** binolike: accepts frequency vector as third input argument

 ** gevfit: accepts frequency vector as third input argument

 ** gevlike: accepts frequency vector as third input argument

 ** gpfit: accepts frequency vector and requires fixed parameter 'theta'

 ** gplike: accepts frequency vector as third input argument

 ** logl* distribution functions: changed parameters for MATLAB compatibility

 ** hnfit: accepts frequency vector as third input argument

 ** hnlike: accepts frequency vector as third input argument

 ** nbinfit: accepts frequency vector as third input argument

 ** nbinlike: accepts frequency vector as third input argument

 ** tri* distribution functions: swapped the order of b and c input arguments

 ** unidfit: accepts frequency vector as third input argument

 ** unifit: accepts frequency vector as third input argument


 Summary of important user-visible changes for statistics 1.6.5:
-------------------------------------------------------------------

 Important Notice: 1) `mad`, `mean`, `median`, `std`, `var` functions
                      shadow core Octave's respective functions prior
                      to Octave v9.1
                   2) incompatibility with the `nan` package

 Improvements:
 =============

 ** mad/median: correct mad handling of vectors with multiple Infs

 ** PiecewiseLinearDistribution: fix truncated `mean`, `std`, and `var` methods

 ** various fixes to avoid errors when testing the package functions


 Summary of important user-visible changes for statistics 1.6.6:
-------------------------------------------------------------------

 Important Notice: 1) `mad`, `mean`, `median`, `std`, `var` functions
                      shadow core Octave's respective functions prior
                      to Octave v9.1
                   2) incompatibility with the `nan` package
 New functions:
 ==============

 ** editDistance

 Improvements:
 =============

 ** fillmissing: combining `movmedian` method and `missinglocation` option
                 no longer ignores non-NaN values.

 ** gumbelinv: fix incorrect return value due to misplaced minus sign

 ** glmfit: fix input validation, parameter parsing, and update documentation

 ** histfit: updated support for other distributions, fixed MATLAB compatibility

 ** plot method for probability distribution objects partially implemented to
    allow plotting PDF and superimposing it over histograms of fitted data.


 Summary of important user-visible changes for statistics 1.6.7:
-------------------------------------------------------------------

 Important Notice: 1) `mad`, `mean`, `median`, `std`, `var` functions
                      shadow core Octave's respective functions prior
                      to Octave v9.1
                   2) incompatibility with the `nan` package
 New functions:
 ==============

 ** bar3

 ** bar3h

 Improvements:
 =============

 ** ClassificationKNN: bug fixes in computing Prior and when parsing
                       explicit ClassNanes (github issue #148)

 ** nanmax: update functionality to support VECDIM and 'all' options, fix error
            when requesting a mutual comparison (savannah bug #65802)

 ** nanmin: update functionality to support VECDIM and 'all' options, fix error
            when requesting a mutual comparison (savannah bug #65802)
