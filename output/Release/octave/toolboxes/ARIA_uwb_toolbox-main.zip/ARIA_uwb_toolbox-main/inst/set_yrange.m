% *************************************************
% Cover Sistemi srl 2018
% Confidential-reserved
% *************************************************
function [ ret_code ] = set_yrange(board, YRangeMin, YRangeMax)
%------------------------------------------------
%------------------------------------------------
% Set the radar vertical range
% global DEFINE_OCTAVE;
% START_CHAR = uint8(hex2dec('FF'));
COMMAND    = uint8('y');
% END_CHAR   = uint8(hex2dec('00'));


command_string = [  COMMAND zeros(1,16)];

index=2;
ui16fps = uint16(YRangeMin);
[command_string, index] = code_int16(command_string, index, ui16fps);
% command_string(index) = END_CHAR;
global CRC_ENGINE;
command_string = command_string(1:index-1);
encoding_and_send(board, CRC_ENGINE, command_string);
% if (DEFINE_OCTAVE==0)
% 	flushinput(board);
% 	fwrite(board,command_string);
% else
% 	srl_flush(board);
% 	srl_write(board,command_string);	
% end;
% Read answer
pause(.01);
stream_in = read_answer_crc(board, CRC_ENGINE);
if (isempty(stream_in)==1)
    ret_code=1;
    return;
end

if (stream_in(1)=='y')
    [~,v] = get_int16(stream_in,2);
    if (v~=YRangeMin)
        ret_code = 1;
        return;
    else
        ret_code = 0;
    end;
else    
    ret_code = 1;
    return;
end;
%------------------------------------------------
%------------------------------------------------
% Now set DAC max
% START_CHAR = uint8(hex2dec('FF'));
COMMAND    = uint8('Y');
% END_CHAR   = uint8(hex2dec('00'));


command_string = [  COMMAND zeros(1,16)];

index=2;
ui16fps = uint16(YRangeMax);
[command_string, index] = code_int16(command_string, index, ui16fps);
% command_string(index) = END_CHAR;
% global CRC_ENGINE;
command_string = command_string(1:index-1);
encoding_and_send(board, CRC_ENGINE, command_string);
% if (DEFINE_OCTAVE==0)
% 	flushinput(board);
% 	fwrite(board,command_string);
% else
% 	srl_flush(board);
% 	srl_write(board,command_string);	
% end;
% Read answer
pause(.01);
stream_in = read_answer_crc(board, CRC_ENGINE);
if (isempty(stream_in)==1)
    ret_code=1;
    return;
end

if (stream_in(1)=='Y')
    [~,v] = get_int16(stream_in,2);
    if (v~=YRangeMax)
        ret_code = 1;
        return;
    else
        ret_code = 0;
    end;
else    
    ret_code = 1;
    return;
end;


end

