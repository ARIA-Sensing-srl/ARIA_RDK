% LTFAT - Deprecated functions
%
%  Peter L. Soendergaard, 2012 - 2023.
%
%  The functions in this directory are deprecated, and their use is
%  no longer recommended. The help of each function provides a
%  description on how to replace the function.
%  
%  Deprecated functions
%    ARG_NORMALIZE	 - Use ARG_SETNORM
%    NORMALIZE	        - Use SETNORM
%    CONVOLVE	        - Use LCONV
%    GABELITISTLASSO   - Use FRANAGROUPLASSO  
%    GABGROUPLASSO     - Use FRANAGROUPLASSO
%    GABLASSO          - Use FRANALASSO
%    GABMULEIGS        - Use FRAMEMULEIGS
%    GABMUL            - Use FRAMEMUL
%    FRAMEMATRIX       - Use FRSYNMATRIX
%    IUFILTERBANK      - Use IFILTERBANK
%    IUNSDGT           - Use INSDGT
%    IUNSDGTREAL       - Use INSDGTREAL
%    TFMAT             - Use FRSYNMATRIX or OPERATORMATRIX
%    UWFBTBOUNDS       - Use WFBTBOUNDS
%    UWPFBTBOUNDS      - Use WPFBTBOUNDS
%    CQT               - Use CQTFILTERS and FILTERBANK
%    ICQT              - Use FILTERBANKDUAL and IFILTERBANK or IFILTERBANKITER
%    ERBLETT           - Use AUDFILTERS with 'erb' and FILTERBANK
%    IERBLETT          - Use FILTERBANKDUAL and IFILTERBANK or IFILTERBANKITER
%
%  For help, bug reports, suggestions etc. please visit 
%  http://github.com/ltfat/ltfat/issues
%
%   Url: http://ltfat.github.io/doc/deprecated/Contents.html

% Copyright (C) 2005-2023 Peter L. Soendergaard <peter@sonderport.dk> and others.
% This file is part of LTFAT version 2.6.0
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

