function [A,B]=ref_wilbounds(g,a,M);

L=length(g);

N=L/a;

F=ref_idwilt(eye(M*N),g,a,M);

S=F'*F;

d=eig(S);

A=min(d);
B=max(d);


%-*- texinfo -*-
%@deftypefn {Function} ref_wilbounds
%@verbatim
%@end verbatim
%@strong{Url}: @url{http://ltfat.github.io/doc/reference/ref_wilbounds.html}
%@end deftypefn

% Copyright (C) 2005-2023 Peter L. Soendergaard <peter@sonderport.dk> and others.
% This file is part of LTFAT version 2.6.0
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <http://www.gnu.org/licenses/>.

